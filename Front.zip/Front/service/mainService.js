class TStudentService {
    constructor() {  }

    getStudent(query) {  }
}