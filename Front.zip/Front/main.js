class TApplication {
    constructor() {
        this.studentService = new TStudentService()
    }
}


$(window).on('load', function() {
    
});
